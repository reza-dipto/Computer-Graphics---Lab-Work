# Kitchen
Computer Graphics Glut OpenGL Project C++

<img src="Glut_Kitchen.jpg">
